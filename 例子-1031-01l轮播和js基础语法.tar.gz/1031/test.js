
                        s=10;
                        alert(s);
                        a=confirm('请确定是否删除此信息')
                        alert(a)
                        b=prompt('请输入一个数值')
                        document.write("<h1>欢迎光临"+b+"</h1>")
			document.write("<h3>这是一个网站</h3>")
      

