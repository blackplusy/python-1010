from django.shortcuts import render
from .models import User
# Create your views here.
def index(request):
    #select * from user
    user=User.objects.all()
    #templates携带参数必须以字典形式回传
    content={'user':user}
    return render(request,'index.html',content)
