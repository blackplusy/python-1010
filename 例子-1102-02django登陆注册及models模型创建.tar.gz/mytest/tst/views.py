from django.shortcuts import render,redirect
from .models import User
from django.http import HttpResponse
from hashlib import md5
# Create your views here.
def login(request):
    return render(request,'login.html')
def login_handler(request):
    username=request.POST.get('username')
    password=request.POST.get('password')
    obj=User.objects.filter(username=username)
    if len(obj)==0:
        return redirect('/register/')
    else:
        if obj[0].username==username and obj[0].password==password:
            return HttpResponse('登陆成功!')
        else:
            return HttpResponse('用户名和密码不正确!')

def register(request):
    return render(request,'regiester.html')
def register_handler(request):
    username=request.POST.get('username')
    password=request.POST.get('password')
    print(username)
    print(password)
    pa=md5()
    pa.update(password.encode('utf8'))
    print(pa.hexdigest())
    #username重名，前面指字段名，=后面指变量名
    obj= User.objects.filter(username=username)
    if len(obj)!=0:
        #重定向到一个地址`
        return redirect('/register/')
    else:
        user=User()
        user.username=username
        user.password=pa.hexdigest()
        user.save()
        #return HttpResponse('注册成功!')
        return redirect('/login/')
