from django.db import models

# Create your models here.
class Banji(models.Model):
    name=models.CharField(max_length=20)
    class Meta:
        db_table='banji'
class User(models.Model):
    username=models.CharField(max_length=20)
    password=models.CharField(max_length=64)
    age=models.IntegerField(default=0)
    #auto_now_add获取当前时间
    birth=models.DateTimeField(default='2018-11-02')
    #图片字段,处理图像 upload_to上传的路径
    touxiang=models.ImageField(upload_to='static/media/',default='')
    #TextField里面会包含若干字符
    address=models.CharField(max_length=200,default='')
    #URLField接收网址
    url=models.URLField(default='')
    #EmailField接收邮件 default只对django有效，null=True是对数据库有效
    email=models.EmailField(default='',null=True)
    #有些数据不是真正删除,是一个删除的标志位 BooleanField NullBooleanField
    isDelete=models.BooleanField(default=False)
    #DecimalField小数类型,max_digits总共有多少位, decimal_places表示小数位数
    price=models.DecimalField(max_digits=5,decimal_places=2,default=0.00)
    banji=models.ForeignKey(to='Banji',default='',on_delete=models.CASCADE)
    class Meta:
        #指定数据库存储的表名
          db_table='user'


