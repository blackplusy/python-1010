from django.apps import AppConfig


class MymoConfig(AppConfig):
    name = 'mymo'
